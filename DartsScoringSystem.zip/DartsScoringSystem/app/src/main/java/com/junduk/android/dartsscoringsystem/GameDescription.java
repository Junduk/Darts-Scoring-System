package com.junduk.android.dartsscoringsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.junduk.android.dartsscoringsystem.R;

public class GameDescription extends AppCompatActivity {
    Button returnDes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_description);
        returnDes = findViewById(R.id.returnToPickingTheGames);
        returnDes.setBackgroundResource(android.R.drawable.btn_default);
    }
    public void setReturnToPickingTheGames(View view){ //method to return to previous activity
        finish();
    }
}