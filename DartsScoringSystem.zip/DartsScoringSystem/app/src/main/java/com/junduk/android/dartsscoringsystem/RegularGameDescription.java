package com.junduk.android.dartsscoringsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RegularGameDescription extends AppCompatActivity {
    Button returnDes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regular_game_description);
        returnDes = findViewById(R.id.returnToPickingTheParameters);
        returnDes.setBackgroundResource(android.R.drawable.btn_default);
    }
    public void setReturnToPickingTheParameters(View view){
        finish();
    }
}