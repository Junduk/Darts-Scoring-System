package com.junduk.android.dartsscoringsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button regularGame, desGames, splitScore, cricket;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        regularGame = findViewById(R.id.regularGame);
        desGames = findViewById(R.id.descriptionAboutTheGames);
        splitScore = findViewById(R.id.splitScore);
        cricket = findViewById(R.id.cricket);
        regularGame.setBackgroundResource(android.R.drawable.btn_default);
        desGames.setBackgroundResource(android.R.drawable.btn_default);
        splitScore.setBackgroundResource(android.R.drawable.btn_default);
        cricket.setBackgroundResource(android.R.drawable.btn_default);
    }
    public void openRegularGame(View view){
        Intent regGameIntent = new Intent(this, RegularGame.class);
        startActivity(regGameIntent);
    }
    public void openGamesDes(View view) {
        Intent gamesDesIntent = new Intent(this, com.junduk.android.dartsscoringsystem.GameDescription.class);
        startActivity(gamesDesIntent);
    }
    public void openSplitScore(View view){
        Intent splitScoreIntent = new Intent(this, SplitScore.class);
        startActivity(splitScoreIntent);
    }
    public void openCricket(View view){
        Intent splitScoreIntent = new Intent(this, Cricket.class);
        startActivity(splitScoreIntent);
    }
}