package com.junduk.android.dartsscoringsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SplitScoreDescription extends AppCompatActivity {
    Button returnToPickingTheParameters;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_split_score_description);
        returnToPickingTheParameters = findViewById(R.id.returnToPickingTheParameters);
        returnToPickingTheParameters.setBackgroundResource(android.R.drawable.btn_default);
    }
    public void setReturnToPickingTheParameters(View view){
        finish();
    }
}
