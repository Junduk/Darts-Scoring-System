package com.junduk.android.dartsscoringsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CricketDescription extends AppCompatActivity {
    Button returnToPickingTheParameters;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cricket_description);
        returnToPickingTheParameters = findViewById(R.id.returnToPickingParameters);
        returnToPickingTheParameters.setBackgroundResource(android.R.drawable.btn_default);
    }
    public void setReturnToPickingTheParameters(View view){
        finish();
    }
}
